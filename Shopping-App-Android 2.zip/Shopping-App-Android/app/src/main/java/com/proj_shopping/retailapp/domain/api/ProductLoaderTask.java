package com.proj_shopping.retailapp.domain.api;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.proj_shopping.retailapp.domain.mock.FakeWebServer;
import com.proj_shopping.retailapp.model.CenterRepository;
import com.proj_shopping.retailapp.view.activities.ECartHomeActivity;
import com.proj_shopping.retailapp.view.adapter.ProductsInCategoryPagerAdapter;
import com.proj_shopping.retailapp.view.fragment.ProductListFragment;

import java.util.Set;
/**
 * The Class ImageLoaderTask.
 */
@SuppressLint("StaticFieldLeak")
public class ProductLoaderTask extends AsyncTask<String, Void, Void> {

    private Context context;
    private ViewPager viewPager;
    private TabLayout tabs;
    private RecyclerView recyclerView;

    public ProductLoaderTask(RecyclerView listView, Context context,
                             ViewPager viewpager, TabLayout tabs) {
        this.viewPager = viewpager;
        this.tabs = tabs;
        this.context = context;
    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        if (null != ((ECartHomeActivity) context).getProgressBar())
            ((ECartHomeActivity) context).getProgressBar().setVisibility(
                    View.VISIBLE);
    }

    @Override
    protected void onPostExecute(Void result) {
        super.onPostExecute(result);
        if (null != ((ECartHomeActivity) context).getProgressBar())
            ((ECartHomeActivity) context).getProgressBar().setVisibility(
                    View.GONE);
        setUpUi();
    }

    @Override
    protected Void doInBackground(String... params) {

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        FakeWebServer.getFakeWebServer().getAllGroceries();
        return null;
    }
    private void setUpUi() {
        setupViewPager();
    }

    private void setupViewPager() {
        ProductsInCategoryPagerAdapter adapter = new ProductsInCategoryPagerAdapter(
                ((ECartHomeActivity) context).getSupportFragmentManager());

        Set<String> keys = CenterRepository.getCenterRepository().getMapOfProductsInCategory()
                .keySet();
        for (String string : keys) {
            adapter.addFrag(new ProductListFragment(string), string);
        }
        viewPager.setAdapter(adapter);

        tabs.setupWithViewPager(viewPager);
    }
}