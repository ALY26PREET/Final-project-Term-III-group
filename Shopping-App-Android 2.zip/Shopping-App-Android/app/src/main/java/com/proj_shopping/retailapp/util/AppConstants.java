/*
 *  
 *  
 * Shopping Project
 * 
 *   
 */

package com.proj_shopping.retailapp.util;


public class AppConstants {

    public static final String FIRST_TIME = "FirstTime";
    public static final String WHATS_NEW_LAST_SHOWN = "whats_new_last_shown";
    // Audio preferences
    public static final String VIEW_PAGER_ANIME = "PagerAnime";
    // Help Preference
    public static final String SUBMIT_LOGS = "CrashLogs";
    public static int CURRENT_CATEGORY = 0;


}
