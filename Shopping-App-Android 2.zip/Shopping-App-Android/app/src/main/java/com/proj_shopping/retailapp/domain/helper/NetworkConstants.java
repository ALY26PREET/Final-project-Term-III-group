package com.proj_shopping.retailapp.domain.helper;

/**
 * The Interface NetworkConstants.
 */
public interface NetworkConstants {
    public boolean DEBUGABLE = true;

    public static final String URL_BASE_URI = "";
    public static final String URL_GET_ALL_CATEGORY = URL_BASE_URI
            + "categories";
    public static final String URL_GET_PRODUCTS_MAP = URL_BASE_URI
            + "productMap";
    public static final String URL_PLACE_ORDER = URL_BASE_URI + "insertOrder";

    public static final String URL_APPLY_COUPAN = URL_BASE_URI
            + "validateCoupan";
    public static final int GET_ALL_PRODUCT_BY_CATEGORY = 0;
    public static final int GET_ALL_PRODUCT = 1;
    public static final int GET_SHOPPING_LIST = 9;
}
