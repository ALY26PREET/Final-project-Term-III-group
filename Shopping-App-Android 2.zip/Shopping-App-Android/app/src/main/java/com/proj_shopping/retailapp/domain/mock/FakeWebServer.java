package com.proj_shopping.retailapp.domain.mock;
import com.proj_shopping.retailapp.model.CenterRepository;
import com.proj_shopping.retailapp.model.entities.Product;
import com.proj_shopping.retailapp.model.entities.ProductCategoryModel;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;
/*
 * This class serve as fake server and provides dummy product and category with real Image Urls taken from internet
 */
public class FakeWebServer {
    private static FakeWebServer fakeServer;
    public static FakeWebServer getFakeWebServer() {
        if (null == fakeServer) {
            fakeServer = new FakeWebServer();
        }
        return fakeServer;
    }

    void initiateFakeServer() {
        addCategory();
    }

    public void addCategory() {
        ArrayList<ProductCategoryModel> listOfCategory = new ArrayList<ProductCategoryModel>();

        listOfCategory
                .add(new ProductCategoryModel(
                        "Grocery",
                        "Grocery Items",
                        "10%",
                        "@drawable/cart"));

        listOfCategory
                .add(new ProductCategoryModel(
                        "Household",
                        "Household Items",
                        "15%",
                        ""));

        CenterRepository.getCenterRepository().setListOfCategory(listOfCategory);
    }

    public void getAllGroceries() {

        ConcurrentHashMap<String, ArrayList<Product>> productMap = new ConcurrentHashMap<String, ArrayList<Product>>();
        ArrayList<Product> productlist = new ArrayList<Product>();

        // grocery items
        productlist
                .add(new Product(
                        "Biscuits & Cookies",
                        "Dark Fantasy Cream Biscuits",
                        "Taste the fantasy ",
                        "54",
                        "10",
                        "44",
                        "0",
                        "",
                        "o_1"));

        productlist
                .add(new Product(
                        "Coffee",
                        "Nescafe",
                        "",
                        "50",
                        "10",
                        "40",
                        "0",
                        "",
                        "o_2"));

        productlist
                .add(new Product(
                        "Tea",
                        "Tata Tea Premium",
                        "",
                        "52",
                        "10",
                        "42",
                        "0",
                        "",
                        "o_3"));

        productlist
                .add(new Product(
                        "Horlicks",
                        "Healthdrink",
                        "Women's",
                        "250",
                        "10",
                        "225",
                        "0",
                        "",
                        "o_4"));

        productlist
                .add(new Product(
                        "Soups",
                        "Hot n Sour Knor Soup",
                        "",
                        "40",
                        "10",
                        "35",
                        "0",
                        "",
                        "o_5"));

        productMap.put("Grocery", productlist);
        CenterRepository.getCenterRepository().setMapOfProductsInCategory(productMap);

    }

    public void getAllHouseholds(){

        ConcurrentHashMap<String, ArrayList<Product>> productMap = new ConcurrentHashMap<String, ArrayList<Product>>();

        ArrayList<Product> productlist = new ArrayList<Product>();

        // Products
        productlist
                .add(new Product(
                        "FunFoods Peanut Butter",
                        "Dr.Oetker Peanut Butter Crunchy",
                        "............",
                        "100",
                        "12",
                        "70",
                        "0",
                        "",
                        "t_3"));

        productlist
                .add(new Product(
                        "Quacker Oats",
                        "Steel cut Oats",
                        "...........",
                        "300",
                        "12",
                        "250",
                        "0",
                        "",
                        "t_4"));

        productlist
                .add(new Product(
                        "Nestle Maggi Noodles",
                        "Noodles",
                        "............",
                        "100",
                        "12",
                        "70",
                        "0",
                        "",
                        "t_5"));

        productlist
                .add(new Product(
                        "CornFlakes",
                        "",
                        "",
                        "200",
                        "12",
                        "180",
                        "0",
                        "",
                        "t_6"));

        productMap.put("Eatables", productlist);

        productlist = new ArrayList<Product>();

        // New category array starts "Cleaners"
        productlist
                .add(new Product(
                        "l SurfExcel Easy wash",
                        "Detergent Powder",
                        "",
                        "400",
                        "20",
                        "320",
                        "0",
                        "",
                        "c_1"));

        productlist
                .add(new Product(
                        "l Lizol Disinfectant",
                        "Surface & Floor Cleaner Liquid",
                        "",
                        "290",
                        "10",
                        "250",
                        "0",
                        "",
                        "c_2"));

        productlist
                .add(new Product(
                        "l Dishwashing Gel",
                        "",
                        "",
                        "150",
                        "20",
                        "120",
                        "0",
                        "",
                        "c_3"));

        productMap.put("Household & Cleaners", productlist);


        CenterRepository.getCenterRepository().setMapOfProductsInCategory(productMap);
    }

    public void getAllProducts(int productCategory) {

        if (productCategory == 0) {
            getAllGroceries();
        } else {
            getAllHouseholds();
        }
    }
}
